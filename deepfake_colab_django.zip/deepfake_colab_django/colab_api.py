# Run this file in Google Colab after mounting Google Drive.
# Update CHECKPOINT_PATH and NGROK_AUTHTOKEN before running.

import os, io, threading, time
import numpy as np
import cv2
import torch
import torch.nn as nn
from PIL import Image
from torchvision import models, transforms
from fastapi import FastAPI, UploadFile, File, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from pyngrok import ngrok
from google.colab import drive

# 1. CONFIGURATION
CHECKPOINT_PATH = "/content/drive/MyDrive/deepfake_model.pth"  # change if your file is elsewhere
NGROK_AUTHTOKEN = "PASTE_YOUR_NGROK_AUTHTOKEN_HERE"
API_KEY = "deepfake-project-change-this-key"
IMAGE_SIZE = 224
CLASS_TO_IDX = {"fake": 0, "real": 1}
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 2. MOUNT DRIVE
drive.mount("/content/drive")

# 3. LOAD THE SAME EFFICIENTNET-B0 CHECKPOINT USED IN COLAB
checkpoint = torch.load(CHECKPOINT_PATH, map_location=DEVICE, weights_only=False)

model = models.efficientnet_b0(weights=None)
model.classifier[1] = nn.Linear(model.classifier[1].in_features, 2)

if isinstance(checkpoint, dict) and "model_state_dict" in checkpoint:
    state_dict = checkpoint["model_state_dict"]
elif isinstance(checkpoint, dict) and "state_dict" in checkpoint:
    state_dict = checkpoint["state_dict"]
else:
    state_dict = checkpoint

# Handle checkpoints saved from DataParallel.
state_dict = {k.replace("module.", "", 1) if k.startswith("module.") else k: v
              for k, v in state_dict.items()}
model.load_state_dict(state_dict, strict=True)
model.to(DEVICE)
model.eval()

# 4. SAME IMAGE PREPROCESSING: largest Haar face + 15% margin,
#    RGB, 224x224, ImageNet normalization. If no face, use full image.
cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
face_cascade = cv2.CascadeClassifier(cascade_path)
if face_cascade.empty():
    raise RuntimeError("Could not load Haar face cascade.")

transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

def prepare_image(image_bytes):
    try:
        pil_image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    except Exception:
        raise HTTPException(status_code=400, detail="Uploaded file is not a valid image.")

    rgb = np.array(pil_image)
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30)
    )

    face_detected = len(faces) > 0
    if face_detected:
        x, y, w, h = max(faces, key=lambda box: box[2] * box[3])
        margin_x = int(w * 0.15)
        margin_y = int(h * 0.15)
        x1 = max(0, x - margin_x)
        y1 = max(0, y - margin_y)
        x2 = min(bgr.shape[1], x + w + margin_x)
        y2 = min(bgr.shape[0], y + h + margin_y)
        crop_bgr = bgr[y1:y2, x1:x2]
        crop_rgb = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2RGB)
        pil_image = Image.fromarray(crop_rgb)
    tensor = transform(pil_image).unsqueeze(0).to(DEVICE)
    return tensor, face_detected

# 5. FASTAPI
app = FastAPI(title="Deepfake Detection API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["POST"],
    allow_headers=["*"],
)

@app.get("/")
def home():
    return {"status": "running", "device": str(DEVICE)}

@app.post("/predict")
async def predict(file: UploadFile = File(...), x_api_key: str = Header(default="")):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key.")

    image_bytes = await file.read()
    if not image_bytes:
        raise HTTPException(status_code=400, detail="Empty upload.")
    if len(image_bytes) > 15 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Image is larger than 15 MB.")

    tensor, face_detected = prepare_image(image_bytes)
    with torch.inference_mode():
        logits = model(tensor)
        probs = torch.softmax(logits, dim=1)[0].detach().cpu().numpy()

    fake_probability = float(probs[CLASS_TO_IDX["fake"]])
    real_probability = float(probs[CLASS_TO_IDX["real"]])
    predicted_class = "fake" if fake_probability >= real_probability else "real"
    confidence = max(fake_probability, real_probability) * 100

    return {
        "prediction": predicted_class.upper(),
        "confidence": round(confidence, 2),
        "fake_probability": round(fake_probability * 100, 2),
        "real_probability": round(real_probability * 100, 2),
        "face_detected": bool(face_detected),
        "device": str(DEVICE)
    }

# 6. START NGROK + API
if NGROK_AUTHTOKEN == "PASTE_YOUR_NGROK_AUTHTOKEN_HERE":
    raise ValueError("Paste your ngrok authtoken in NGROK_AUTHTOKEN first.")

ngrok.set_auth_token(NGROK_AUTHTOKEN)
try:
    ngrok.kill()
except Exception:
    pass

def run_api():
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")

thread = threading.Thread(target=run_api, daemon=True)
thread.start()
time.sleep(3)
public_url = ngrok.connect(8000).public_url
print("API is ready:", public_url)
print("Use this URL in Django as COLAB_API_URL:", public_url)
print("Keep this Colab session running while using the Django website.")
