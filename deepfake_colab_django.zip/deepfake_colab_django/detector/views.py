import requests
from django.conf import settings
from django.shortcuts import render
from django.views.decorators.http import require_http_methods

@require_http_methods(["GET", "POST"])
def index(request):
    return render(request, "detector/index.html")

@require_http_methods(["POST"])
def analyze(request):
    uploaded_file = request.FILES.get("image")
    if not uploaded_file:
        return render(request, "detector/index.html", {"error": "Please select an image."})

    if uploaded_file.size > 15 * 1024 * 1024:
        return render(request, "detector/index.html", {"error": "Image must be smaller than 15 MB."})

    api_url = settings.COLAB_API_URL.rstrip("/") + "/predict"
    headers = {"x-api-key": settings.COLAB_API_KEY}

    try:
        response = requests.post(
            api_url,
            headers=headers,
            files={"file": (uploaded_file.name, uploaded_file.file, uploaded_file.content_type)},
            timeout=120
        )
        response.raise_for_status()
        result = response.json()
    except requests.exceptions.Timeout:
        return render(request, "detector/index.html", {
            "error": "Colab API timed out. Check that the Colab cell is still running."
        })
    except requests.exceptions.RequestException as exc:
        detail = "Could not connect to Colab API. Check the ngrok URL and keep Colab running."
        try:
            detail = response.json().get("detail", detail)
        except Exception:
            pass
        return render(request, "detector/index.html", {"error": detail})
    except ValueError:
        return render(request, "detector/index.html", {"error": "Colab returned an invalid response."})

    # These values are displayed directly from Colab; Django does not run another model.
    context = {
        "result": result,
        "image_name": uploaded_file.name,
    }
    return render(request, "detector/index.html", context)
