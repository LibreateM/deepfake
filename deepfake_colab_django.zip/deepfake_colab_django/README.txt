DEEPFAKE DETECTION: COLAB MODEL + DJANGO FRONTEND
================================================

IMPORTANT DESIGN
- The model runs ONLY in Google Colab.
- Django sends the uploaded image to Colab's /predict API.
- Django displays the exact JSON returned by Colab.
- There is no second/local model in Django, so the two interfaces cannot use
  different checkpoints or preprocessing pipelines.

A. GOOGLE COLAB SETUP
---------------------
1. Upload colab_api.py to Colab or copy its contents into a Colab cell.
2. Make sure your checkpoint exists at:
   /content/drive/MyDrive/deepfake_model.pth
   If not, edit CHECKPOINT_PATH near the top of colab_api.py.
3. Install packages in a Colab cell:
   !pip install -q fastapi uvicorn pyngrok python-multipart
4. Create an ngrok account and copy your authtoken.
5. In colab_api.py, replace:
   PASTE_YOUR_NGROK_AUTHTOKEN_HERE
   with your real ngrok authtoken.
6. Keep API_KEY as-is for testing, or choose your own secret string.
7. Run the whole script. It prints an ngrok URL, for example:
   https://abc123.ngrok-free.app
8. Keep the Colab tab/session running while testing the Django site.

B. DJANGO SETUP (NO VIRTUAL ENVIRONMENT)
----------------------------------------
Open Command Prompt/PowerShell in the extracted project folder.

Install packages:
   py -m pip install -r requirements.txt

In deepfake_project/settings.py, update:
   COLAB_API_URL = "https://YOUR-CURRENT-NGROK-URL"
   COLAB_API_KEY = "the-same-API-key-as-colab"

Do not add /predict to COLAB_API_URL.

Run:
   py manage.py migrate
   py manage.py runserver

Open:
   http://127.0.0.1:8000/

C. IMPORTANT
------------
- Colab's ngrok URL can change whenever the Colab script is restarted. Update
  COLAB_API_URL in settings.py each time it changes.
- The API key in Django and Colab must match exactly.
- If Colab disconnects, Django cannot analyze images until Colab is running again.
- This package assumes your checkpoint is an EfficientNet-B0 PyTorch state dict
  with a 2-output classifier and class mapping fake=0, real=1.
- The preprocessing included here is largest Haar face crop with 15% margin,
  RGB, resize 224x224, and ImageNet normalization. It is based on the project
  setup previously established. To guarantee bit-for-bit identical output,
  this preprocessing must match the exact inference cell used for the Colab
  result in your PDF.
- A confidence score is a model score, not a guarantee that the image is fake
  or real.
